/*const awsServerlessExpress = require('aws-serverless-express');
const app = require('./app');
const serverLess = awsServerlessExpress.createServer(app);
module.exports.handler = serverLess;

 exports.handler = (event, context) => {
  awsServerlessExpress.proxy(server, event, context);
};
 */

const awsServerlessExpress = require('aws-serverless-express');
const app = require('./app'); // Import your Express app
const server = awsServerlessExpress.createServer(app);

exports.handler = (event, context) => {
  awsServerlessExpress.proxy(server, event, context);
};
